#!/bin/bash

# =============================================================================
# 纯Bash流量监控脚本 - Ubuntu 24.04 LTS专用
# 功能：监控节点服务器流量并上报给后端API
# 依赖：仅需要curl（Ubuntu默认已安装）
# =============================================================================

# 配置参数
API_BASE_URL="http://173.230.128.51:8080"
SERVER_ID="node-170-187-252-254"
API_TOKEN="fgfrerrhtrytrytrfdgdgdfggrtre"
REPORT_INTERVAL=60  # 上报间隔（秒）
LOG_FILE="/var/log/traffic-monitor.log"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log_info() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')] INFO:${NC} $1" | tee -a "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] SUCCESS:${NC} $1" | tee -a "$LOG_FILE"
}

log_warning() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARNING:${NC} $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR:${NC} $1" | tee -a "$LOG_FILE"
}

# 获取主网络接口名称
get_main_interface() {
    # 获取默认路由的接口
    ip route | grep default | head -1 | awk '{print $5}'
}

# 获取接口流量统计
get_interface_stats() {
    local interface="$1"
    if [ ! -d "/sys/class/net/$interface" ]; then
        echo "0 0"
        return
    fi
    
    local rx_bytes=$(cat "/sys/class/net/$interface/statistics/rx_bytes" 2>/dev/null || echo "0")
    local tx_bytes=$(cat "/sys/class/net/$interface/statistics/tx_bytes" 2>/dev/null || echo "0")
    
    echo "$rx_bytes $tx_bytes"
}

# 获取活跃连接数
get_active_connections() {
    # 统计到VPN端口的连接数
    netstat -tn 2>/dev/null | grep -E ':(443|80|8080|1080|10808)' | grep ESTABLISHED | wc -l
}

# 通过API查询真实用户名
get_real_username() {
    local client_ip="$1"
    
    local response=$(curl -s -X POST "$API_BASE_URL/api/traffic/get-user" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_TOKEN" \
        -d "{
            \"server_id\":\"$SERVER_ID\",
            \"client_ip\":\"$client_ip\",
            \"action\":\"get_active_users\"
        }" \
        --connect-timeout 10 \
        --max-time 15 2>/dev/null)
    
    if [ $? -eq 0 ] && [ -n "$response" ]; then
        # 解析JSON响应获取用户名
        local username=$(echo "$response" | grep -o '"username":"[^"]*"' | cut -d'"' -f4)
        if [ -n "$username" ] && [ "$username" != "null" ]; then
            echo "$username"
            return 0
        fi
    fi
    
    return 1
}

# 上报流量数据
report_traffic() {
    local username="$1"
    local bytes_used="$2"
    local connection_count="$3"
    
    local payload="{
        \"server_id\":\"$SERVER_ID\",
        \"username\":\"$username\",
        \"connection_id\":\"conn_${username}_$(date +%s)\",
        \"bytes_used\":$bytes_used,
        \"event_type\":\"periodic\",
        \"timestamp\":$(date +%s),
        \"connection_count\":$connection_count
    }"
    
    local response=$(curl -s -X POST "$API_BASE_URL/api/traffic/report" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_TOKEN" \
        -d "$payload" \
        --connect-timeout 10 \
        --max-time 15 2>/dev/null)
    
    if [ $? -eq 0 ]; then
        if echo "$response" | grep -q '"success":true'; then
            log_success "✅ 用户 $username 流量上报成功: $(format_bytes $bytes_used)"
            return 0
        else
            log_error "❌ 用户 $username 上报失败: $response"
            return 1
        fi
    else
        log_error "❌ 网络请求失败，无法上报流量"
        return 1
    fi
}

# 格式化字节数
format_bytes() {
    local bytes=$1
    if [ $bytes -gt 1073741824 ]; then
        echo "$(($bytes / 1073741824))GB"
    elif [ $bytes -gt 1048576 ]; then
        echo "$(($bytes / 1048576))MB"
    elif [ $bytes -gt 1024 ]; then
        echo "$(($bytes / 1024))KB"
    else
        echo "${bytes}B"
    fi
}

# 发送心跳
send_heartbeat() {
    local payload="{
        \"server_id\":\"$SERVER_ID\",
        \"timestamp\":$(date +%s),
        \"status\":\"online\"
    }"
    
    # 🔧 修复：使用正确的心跳API端点
    local response=$(curl -s -w "HTTPSTATUS:%{http_code}" -X POST "$API_BASE_URL/api/traffic/heartbeat" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_TOKEN" \
        -d "$payload" \
        --connect-timeout 5 \
        --max-time 10)

    # 解析响应
    local http_code=$(echo "$response" | tr -d '\n' | sed -e 's/.*HTTPSTATUS://')
    local body=$(echo "$response" | sed -e 's/HTTPSTATUS\:.*//g')

    if [ "$http_code" = "200" ]; then
        log_info "💓 心跳发送成功: $body"
    else
        log_error "💔 心跳发送失败: HTTP $http_code, $body"
    fi
}

# 主监控循环
main_monitor_loop() {
    local interface=$(get_main_interface)
    local last_rx=0
    local last_tx=0
    local heartbeat_counter=0
    
    log_info "🚀 开始流量监控..."
    log_info "📡 监控网络接口: $interface"
    log_info "🔄 上报间隔: ${REPORT_INTERVAL}秒"
    
    # 获取初始流量数据
    read last_rx last_tx <<< $(get_interface_stats "$interface")
    
    while true; do
        sleep $REPORT_INTERVAL
        
        # 获取当前流量数据
        read current_rx current_tx <<< $(get_interface_stats "$interface")
        
        # 计算流量差值
        local rx_diff=$((current_rx - last_rx))
        local tx_diff=$((current_tx - last_tx))
        local total_diff=$((rx_diff + tx_diff))
        
        # 获取连接数
        local connections=$(get_active_connections)
        
        if [ $total_diff -gt 0 ]; then
            log_info "📊 检测到流量: $(format_bytes $total_diff), 连接数: $connections"
            
            # 尝试获取真实用户名
            local username=""
            if [ $connections -gt 0 ]; then
                username=$(get_real_username "auto")
            fi
            
            # 如果没有获取到真实用户名，使用服务器ID作为用户标识
            if [ -z "$username" ]; then
                username="server_$SERVER_ID"
                log_warning "⚠️ 未找到真实用户名，使用服务器标识: $username"
            else
                log_info "🔍 找到真实用户: $username"
            fi
            
            # 上报流量
            report_traffic "$username" "$total_diff" "$connections"
        else
            log_info "📊 无流量变化，连接数: $connections"
        fi
        
        # 更新上次的流量数据
        last_rx=$current_rx
        last_tx=$current_tx
        
        # 每5分钟发送一次心跳
        heartbeat_counter=$((heartbeat_counter + 1))
        if [ $((heartbeat_counter % 5)) -eq 0 ]; then
            send_heartbeat
            log_info "💓 发送心跳信号"
        fi
    done
}

# 检查依赖
check_dependencies() {
    if ! command -v curl >/dev/null 2>&1; then
        log_error "❌ curl 未安装，请先安装: apt install -y curl"
        exit 1
    fi
    
    if ! command -v netstat >/dev/null 2>&1; then
        log_warning "⚠️ netstat 未安装，连接统计功能受限"
    fi
    
    log_success "✅ 依赖检查通过"
}

# 信号处理
cleanup() {
    log_info "🛑 收到停止信号，正在清理..."
    exit 0
}

trap cleanup SIGTERM SIGINT

# 主函数
main() {
    log_info "🎯 启动纯Bash流量监控脚本"
    log_info "🖥️  服务器ID: $SERVER_ID"
    log_info "🌐 API地址: $API_BASE_URL"
    
    check_dependencies
    main_monitor_loop
}

# 如果直接运行此脚本
if [ "${BASH_SOURCE[0]}" == "${0}" ]; then
    main "$@"
fi
