#!/bin/bash

# =============================================================================
# 纯Bash流量监控脚本 - Ubuntu 24.04 LTS专用
# 功能：监控节点服务器流量并上报给后端API
# 依赖：仅需要curl（Ubuntu默认已安装）
# =============================================================================

# 配置参数
API_BASE_URL="http://173.230.128.51:8080"
SERVER_ID="node-$(hostname -I | awk '{print $1}' | tr '.' '-')"  # 🔧 自动检测服务器IP并生成ID
API_TOKEN="fgfrerrhtrytrytrfdgdgdfggrtre"
REPORT_INTERVAL=120  # 上报间隔（秒）
LOG_FILE="/var/log/traffic-monitor.log"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log_info() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')] INFO:${NC} $1" | tee -a "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] SUCCESS:${NC} $1" | tee -a "$LOG_FILE"
}

log_warning() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARNING:${NC} $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR:${NC} $1" | tee -a "$LOG_FILE"
}

# 获取主网络接口名称
get_main_interface() {
    # 获取默认路由的接口
    ip route | grep default | head -1 | awk '{print $5}'
}

# 获取接口流量统计
get_interface_stats() {
    local interface="$1"
    if [ ! -d "/sys/class/net/$interface" ]; then
        echo "0 0"
        return
    fi
    
    local rx_bytes=$(cat "/sys/class/net/$interface/statistics/rx_bytes" 2>/dev/null || echo "0")
    local tx_bytes=$(cat "/sys/class/net/$interface/statistics/tx_bytes" 2>/dev/null || echo "0")
    
    echo "$rx_bytes $tx_bytes"
}

# 获取活跃连接数
get_active_connections() {
    # 统计到VPN端口的连接数
    netstat -tn 2>/dev/null | grep -E ':(443|80|8080|1080|10808)' | grep ESTABLISHED | wc -l
}

# 🔧 真实流量监控：获取所有活跃用户和IP映射
get_all_active_users_with_ips() {
    local response=$(curl -s -X POST "$API_BASE_URL/api/traffic/get-user" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_TOKEN" \
        -d "{
            \"server_id\":\"$SERVER_ID\",
            \"client_ip\":\"auto\",
            \"action\":\"get_all_active_users\"
        }" \
        --connect-timeout 10 \
        --max-time 15 2>/dev/null)

    if [ $? -eq 0 ] && [ -n "$response" ]; then
        # 检查API是否成功返回
        if echo "$response" | grep -q '"success":true'; then
            # 解析JSON响应中的users数组
            local users_array=$(echo "$response" | grep -o '"users":\[[^]]*\]' | sed 's/"users":\[\(.*\)\]/\1/')
            if [ -n "$users_array" ]; then
                # 提取用户名列表，去掉引号和空格
                local users=$(echo "$users_array" | sed 's/"//g' | sed 's/,/\n/g' | sed 's/^ *//g' | sed 's/ *$//g')
                if [ -n "$users" ]; then
                    # 🔧 严格过滤用户名，只保留有效用户
                    local valid_users=""
                    while IFS= read -r username; do
                        if [ -n "$username" ] && [[ "$username" =~ ^[a-zA-Z0-9_-]+$ ]] && [[ ${#username} -le 15 ]] && [[ "$username" != *"INFO:"* ]] && [[ "$username" != *"WARNING:"* ]] && [[ "$username" != *"ERROR:"* ]] && [[ "$username" != *"SUCCESS:"* ]] && [[ "$username" != *"["* ]] && [[ "$username" != *"2025-"* ]]; then
                            if [ -n "$valid_users" ]; then
                                valid_users="$valid_users\n$username"
                            else
                                valid_users="$username"
                            fi
                        else
                            if [ -n "$username" ]; then
                                log_warning "⚠️ 过滤无效用户名: '$username'" >&2
                            fi
                        fi
                    done <<< "$users"

                    if [ -n "$valid_users" ]; then
                        log_info "🔍 获取到有效活跃用户: $(echo -e "$valid_users" | tr '\n' ',' | sed 's/,$//')" >&2

                        # 🔧 修复：只基于API返回的用户创建映射，不依赖TCP连接
                        # 获取当前VPN连接的IP列表
                        local connection_ips=$(get_all_vpn_client_ips)

                        # 建立用户和IP的映射关系
                        build_user_ip_mapping "$valid_users" "$connection_ips"
                        return 0
                    else
                        log_warning "⚠️ 没有有效的活跃用户" >&2
                        return 1  # 🔧 修复：明确返回失败
                    fi
                fi
            fi
            log_warning "⚠️ API返回成功但无法解析用户列表: $response" >&2
            return 1  # 🔧 修复：API返回空用户时明确返回失败
        else
            log_warning "⚠️ API返回失败: $response" >&2
        fi
    else
        log_warning "⚠️ 无法连接到API获取活跃用户列表" >&2
    fi

    return 1
}

# 🆕 获取所有VPN客户端IP
get_all_vpn_client_ips() {
    # 获取所有到VPN端口的连接，提取唯一的客户端IP
    netstat -tn 2>/dev/null | grep -E ':(443|80|8080|1080|10808)' | grep ESTABLISHED | while read line; do
        # 解析netstat输出格式
        # 示例：tcp 0 0 192.168.1.100:443 112.114.43.167:54321 ESTABLISHED
        local client_ip=$(echo "$line" | awk '{print $5}' | cut -d':' -f1)

        if [ -n "$client_ip" ] && [ "$client_ip" != "127.0.0.1" ] && [ "$client_ip" != "::1" ]; then
            echo "$client_ip"
        fi
    done | sort -u
}

# 🆕 建立用户IP映射关系
build_user_ip_mapping() {
    local users="$1"
    local connection_ips="$2"

    if [ -z "$connection_ips" ]; then
        log_warning "⚠️ 未检测到VPN连接IP"
        return 1
    fi

    log_info "🔍 检测到VPN连接IP: $(echo "$connection_ips" | tr '\n' ',' | sed 's/,$//')"

    # 简单映射策略：按顺序分配IP给用户
    local ip_index=0
    while IFS= read -r username; do
        # 🔧 更严格的用户名过滤：只接受字母数字组合的用户名，统一15字符限制
        if [ -n "$username" ] && [[ "$username" =~ ^[a-zA-Z0-9_-]+$ ]] && [[ ${#username} -le 15 ]] && [[ "$username" != *"INFO:"* ]] && [[ "$username" != *"WARNING:"* ]] && [[ "$username" != *"ERROR:"* ]] && [[ "$username" != *"SUCCESS:"* ]] && [[ "$username" != *"["* ]] && [[ "$username" != *"2025-"* ]]; then
            local current_ip=$(echo "$connection_ips" | sed -n "$((ip_index + 1))p")
            if [ -n "$current_ip" ]; then
                echo "$username:$current_ip"
                ip_index=$((ip_index + 1))
                log_info "🔗 映射用户 $username → IP $current_ip"
            fi
        else
            # 🔧 调试：显示被过滤的无效用户名
            if [ -n "$username" ]; then
                log_warning "⚠️ 过滤无效用户名: '$username'"
            fi
        fi
    done <<< "$users"
}

# 🔧 兼容性：保留旧函数
get_all_active_users() {
    get_all_active_users_with_ips | cut -d':' -f1
}

# 🔧 真实流量监控：为每个用户创建独立的iptables监控规则（基于原始设计）
create_user_traffic_monitoring() {
    local username="$1"

    if [ -z "$username" ]; then
        log_error "❌ 用户名为空，无法创建监控规则"
        return 1
    fi

    # 🔧 验证用户名有效性：只允许字母数字下划线，长度限制在15字符以内（iptables链名限制）
    if ! [[ "$username" =~ ^[a-zA-Z0-9_-]+$ ]] || [ ${#username} -gt 15 ]; then
        log_error "❌ 用户名无效或过长: '$username' (长度: ${#username}, 限制: 15字符)"
        return 1
    fi

    log_info "🔍 开始为用户 $username 创建流量监控规则"

    # 检查用户是否已在监控中，如果是则先清理
    if iptables -L "user_${username}_in" >/dev/null 2>&1; then
        log_info "⚠️ 用户 $username 已在监控中，先清理旧规则"
        cleanup_user_traffic_monitoring "$username"
    fi

    # 创建用户专用的iptables链
    iptables -N "user_${username}_in" 2>/dev/null || true
    iptables -N "user_${username}_out" 2>/dev/null || true

    # 🔧 监控VPN端口的流量（基于原始脚本逻辑）
    # 入站流量：用户连接到VPN服务器
    iptables -I INPUT -p tcp --dport 443 -m comment --comment "user_${username}_in" -j "user_${username}_in"
    iptables -A "user_${username}_in" -j ACCEPT

    # 出站流量：VPN服务器响应用户
    iptables -I OUTPUT -p tcp --sport 443 -m comment --comment "user_${username}_out" -j "user_${username}_out"
    iptables -A "user_${username}_out" -j ACCEPT

    # 🔧 也监控其他常用VPN端口
    for port in 80 8080 1080 10808; do
        iptables -I INPUT -p tcp --dport $port -m comment --comment "user_${username}_in" -j "user_${username}_in" 2>/dev/null
        iptables -I OUTPUT -p tcp --sport $port -m comment --comment "user_${username}_out" -j "user_${username}_out" 2>/dev/null
    done

    log_info "✅ 用户 $username 流量监控规则创建成功"
    return 0
}

# 🔧 真实流量监控：获取用户的实际流量使用量（基于原始设计）
get_user_real_traffic_usage() {
    local username="$1"

    if [ -z "$username" ]; then
        echo "0"
        return 1
    fi

    # 🔧 从入站和出站链获取字节数（原始脚本逻辑）
    local bytes_in=$(iptables -L "user_${username}_in" -v -n -x 2>/dev/null | \
                     awk '/ACCEPT/ {sum+=$2} END {print sum+0}')
    local bytes_out=$(iptables -L "user_${username}_out" -v -n -x 2>/dev/null | \
                      awk '/ACCEPT/ {sum+=$2} END {print sum+0}')
    local total_bytes=$((bytes_in + bytes_out))

    echo "$total_bytes"
    return 0
}

# 🔧 真实流量监控：清理用户的监控规则（基于原始设计）
cleanup_user_traffic_monitoring() {
    local username="$1"

    if [ -z "$username" ]; then
        log_error "清理监控失败：用户名为空"
        return 1
    fi

    log_info "🧹 开始清理用户 $username 的流量监控规则和iptables规则"

    # 🔧 增强：记录清理前的规则数量
    local rules_before
    rules_before=$(iptables -L | grep -c "user_${username}" 2>/dev/null || echo "0")
    # 确保rules_before是数字
    if ! [[ "$rules_before" =~ ^[0-9]+$ ]]; then
        rules_before=0
    fi
    log_info "   清理前发现 $rules_before 条相关iptables规则"

    # 🔧 清除INPUT和OUTPUT链的规则（原始脚本逻辑）
    iptables -D INPUT -p tcp --dport 443 -m comment --comment "user_${username}_in" -j "user_${username}_in" 2>/dev/null
    iptables -D OUTPUT -p tcp --sport 443 -m comment --comment "user_${username}_out" -j "user_${username}_out" 2>/dev/null

    # 清理其他端口
    for port in 80 8080 1080 10808; do
        iptables -D INPUT -p tcp --dport $port -m comment --comment "user_${username}_in" -j "user_${username}_in" 2>/dev/null
        iptables -D OUTPUT -p tcp --sport $port -m comment --comment "user_${username}_out" -j "user_${username}_out" 2>/dev/null
    done

    # 清除用户专用链
    iptables -F "user_${username}_in" 2>/dev/null
    iptables -X "user_${username}_in" 2>/dev/null
    iptables -F "user_${username}_out" 2>/dev/null
    iptables -X "user_${username}_out" 2>/dev/null

    # 🔧 增强：验证清理结果
    local rules_after
    rules_after=$(iptables -L | grep -c "user_${username}" 2>/dev/null || echo "0")
    # 确保rules_after是数字
    if ! [[ "$rules_after" =~ ^[0-9]+$ ]]; then
        rules_after=0
    fi

    local rules_cleaned=0
    if [[ "$rules_before" =~ ^[0-9]+$ ]] && [[ "$rules_after" =~ ^[0-9]+$ ]]; then
        rules_cleaned=$((rules_before - rules_after))
    fi

    if [ "$rules_after" -eq 0 ]; then
        log_success "✅ 用户 $username 的所有iptables规则已完全清理 (清理了 $rules_cleaned 条规则)"
    else
        log_warning "⚠️ 用户 $username 仍有 $rules_after 条iptables规则未清理完成"
    fi

    return 0
}





# 🔧 兼容性：保留旧函数，返回第一个用户
get_real_username() {
    local client_ip="$1"

    local response=$(curl -s -X POST "$API_BASE_URL/api/traffic/get-user" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_TOKEN" \
        -d "{
            \"server_id\":\"$SERVER_ID\",
            \"client_ip\":\"$client_ip\",
            \"action\":\"get_active_users\"
        }" \
        --connect-timeout 10 \
        --max-time 15 2>/dev/null)

    if [ $? -eq 0 ] && [ -n "$response" ]; then
        # 解析JSON响应获取用户名
        local username=$(echo "$response" | grep -o '"username":"[^"]*"' | cut -d'"' -f4)
        if [ -n "$username" ] && [ "$username" != "null" ]; then
            echo "$username"
            return 0
        fi
    fi

    return 1
}

# 上报流量数据
report_traffic() {
    local username="$1"
    local bytes_used="$2"
    local connection_count="$3"
    local client_ip="$4"  # 🆕 新增：客户端IP参数

    local payload="{
        \"server_id\":\"$SERVER_ID\",
        \"username\":\"$username\",
        \"connection_id\":\"conn_${username}_$(date +%s)\",
        \"bytes_used\":$bytes_used,
        \"event_type\":\"periodic\",
        \"timestamp\":$(date +%s),
        \"connection_count\":$connection_count"

    # 🆕 如果有IP信息，添加到payload中
    if [ -n "$client_ip" ]; then
        payload="${payload},\"client_ip\":\"$client_ip\""
    fi

    payload="${payload}}"
    
    local response=$(curl -s -X POST "$API_BASE_URL/api/traffic/report" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_TOKEN" \
        -d "$payload" \
        --connect-timeout 10 \
        --max-time 15 2>/dev/null)
    
    if [ $? -eq 0 ]; then
        if echo "$response" | grep -q '"success":true'; then
            log_success "✅ 用户 $username 流量上报成功: $(format_bytes $bytes_used)"
            return 0
        else
            log_error "❌ 用户 $username 上报失败: $response"
            return 1
        fi
    else
        log_error "❌ 网络请求失败，无法上报流量"
        return 1
    fi
}

# 格式化字节数
format_bytes() {
    local bytes=$1
    if [ $bytes -gt 1073741824 ]; then
        echo "$(($bytes / 1073741824))GB"
    elif [ $bytes -gt 1048576 ]; then
        echo "$(($bytes / 1048576))MB"
    elif [ $bytes -gt 1024 ]; then
        echo "$(($bytes / 1024))KB"
    else
        echo "${bytes}B"
    fi
}

# 🛡️ ==================== 安全规则管理功能 ====================

# 获取当前安全规则版本
get_current_security_version() {
    local version_file="/tmp/security_rules_version"
    if [ -f "$version_file" ]; then
        cat "$version_file"
    else
        echo "v1.0.0"
    fi
}

# 保存安全规则版本
save_security_version() {
    local version="$1"
    echo "$version" > "/tmp/security_rules_version"
}

# 应用IP黑名单规则
apply_ip_blacklist() {
    local rules_file="$1"

    # 创建或清空IP黑名单链
    iptables -F SECURITY_BLACKLIST_IP 2>/dev/null || iptables -N SECURITY_BLACKLIST_IP

    # 从JSON中提取IP黑名单并应用
    if command -v jq >/dev/null 2>&1; then
        jq -r '.blacklist[] | select(.type=="ip") | .value' "$rules_file" 2>/dev/null | while read -r ip; do
            if [ -n "$ip" ] && [ "$ip" != "null" ]; then
                iptables -A SECURITY_BLACKLIST_IP -s "$ip" -j DROP
                iptables -A SECURITY_BLACKLIST_IP -d "$ip" -j DROP
                log_info "🚫 已阻止IP: $ip"
            fi
        done
    else
        # 如果没有jq，使用简单的文本处理
        grep -o '"type":"ip"[^}]*"value":"[^"]*"' "$rules_file" 2>/dev/null | \
        sed 's/.*"value":"\([^"]*\)".*/\1/' | while read -r ip; do
            if [ -n "$ip" ]; then
                iptables -A SECURITY_BLACKLIST_IP -s "$ip" -j DROP
                iptables -A SECURITY_BLACKLIST_IP -d "$ip" -j DROP
                log_info "🚫 已阻止IP: $ip"
            fi
        done
    fi

    # 将黑名单链插入到主链中
    iptables -C INPUT -j SECURITY_BLACKLIST_IP 2>/dev/null || iptables -I INPUT -j SECURITY_BLACKLIST_IP
    iptables -C OUTPUT -j SECURITY_BLACKLIST_IP 2>/dev/null || iptables -I OUTPUT -j SECURITY_BLACKLIST_IP
}

# 🆕 应用域名黑名单规则
apply_domain_blacklist() {
    local rules_file="$1"

    log_info "🌐 开始应用域名黑名单规则..."

    # 从JSON中提取域名黑名单并应用
    if command -v jq >/dev/null 2>&1; then
        jq -r '.blacklist[] | select(.type=="domain") | .value' "$rules_file" 2>/dev/null | while read -r domain; do
            if [ -n "$domain" ] && [ "$domain" != "null" ]; then
                apply_domain_block "$domain"
            fi
        done
    else
        # 如果没有jq，使用简单的文本处理
        grep -o '"type":"domain"[^}]*"value":"[^"]*"' "$rules_file" 2>/dev/null | \
        sed 's/.*"value":"\([^"]*\)".*/\1/' | while read -r domain; do
            if [ -n "$domain" ]; then
                apply_domain_block "$domain"
            fi
        done
    fi
}

# 🆕 应用单个域名阻止（完全阻止访问）
apply_domain_block() {
    local domain="$1"

    # 方案1: 先解析真实IP并阻止
    local domain_ips=""
    if command -v nslookup >/dev/null 2>&1; then
        # 使用公共DNS解析真实IP
        domain_ips=$(nslookup "$domain" 8.8.8.8 2>/dev/null | grep "Address:" | grep -v "#53" | awk '{print $2}' | head -10)
    elif command -v dig >/dev/null 2>&1; then
        domain_ips=$(dig @8.8.8.8 +short "$domain" 2>/dev/null | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -10)
    fi

    if [ -n "$domain_ips" ]; then
        for ip in $domain_ips; do
            if [ -n "$ip" ] && [[ "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
                # 阻止所有到该IP的连接
                iptables -A SECURITY_BLACKLIST_IP -d "$ip" -j REJECT --reject-with icmp-host-unreachable
                iptables -A SECURITY_BLACKLIST_IP -s "$ip" -j REJECT --reject-with icmp-host-unreachable
                log_info "🚫 已阻止域名IP: $domain -> $ip (REJECT)"
            fi
        done
    else
        log_warning "⚠️ 无法解析域名IP: $domain"
    fi

    # 方案2: DNS劫持到无效地址（防止绕过）
    if ! grep -q "^127\.0\.0\.1.*$domain" /etc/hosts 2>/dev/null; then
        # 使用127.0.0.1而不是0.0.0.0，这样会立即拒绝连接
        echo "127.0.0.1 $domain" >> /etc/hosts
        echo "127.0.0.1 www.$domain" >> /etc/hosts
        echo "127.0.0.1 m.$domain" >> /etc/hosts
        echo "127.0.0.1 mobile.$domain" >> /etc/hosts
        log_info "🚫 已阻止域名(DNS劫持): $domain -> 127.0.0.1"
    fi

    # 方案3: 阻止本地回环连接（防止127.0.0.1绕过）
    iptables -A OUTPUT -d 127.0.0.1 -p tcp --dport 80 -j REJECT --reject-with tcp-reset
    iptables -A OUTPUT -d 127.0.0.1 -p tcp --dport 443 -j REJECT --reject-with tcp-reset
}

# 应用端口限制规则
apply_port_restrictions() {
    local rules_file="$1"

    # 创建或清空端口限制链
    iptables -F SECURITY_PORT_RESTRICTIONS 2>/dev/null || iptables -N SECURITY_PORT_RESTRICTIONS

    # 应用端口限制
    if command -v jq >/dev/null 2>&1; then
        jq -r '.port_restrictions[] | select(.type=="block") | "\(.port) \(.protocol)"' "$rules_file" 2>/dev/null | while read -r port protocol; do
            if [ -n "$port" ] && [ "$port" != "null" ] && [ -n "$protocol" ] && [ "$protocol" != "null" ]; then
                if [ "$protocol" = "tcp" ] || [ "$protocol" = "both" ]; then
                    iptables -A SECURITY_PORT_RESTRICTIONS -p tcp --dport "$port" -j DROP
                    log_info "🚫 已阻止TCP端口: $port"
                fi
                if [ "$protocol" = "udp" ] || [ "$protocol" = "both" ]; then
                    iptables -A SECURITY_PORT_RESTRICTIONS -p udp --dport "$port" -j DROP
                    log_info "🚫 已阻止UDP端口: $port"
                fi
            fi
        done
    else
        # 简单的文本处理方式
        grep -o '"type":"block"[^}]*"port":[0-9]*[^}]*"protocol":"[^"]*"' "$rules_file" 2>/dev/null | \
        sed 's/.*"port":\([0-9]*\).*"protocol":"\([^"]*\)".*/\1 \2/' | while read -r port protocol; do
            if [ -n "$port" ] && [ -n "$protocol" ]; then
                if [ "$protocol" = "tcp" ] || [ "$protocol" = "both" ]; then
                    iptables -A SECURITY_PORT_RESTRICTIONS -p tcp --dport "$port" -j DROP
                    log_info "🚫 已阻止TCP端口: $port"
                fi
                if [ "$protocol" = "udp" ] || [ "$protocol" = "both" ]; then
                    iptables -A SECURITY_PORT_RESTRICTIONS -p udp --dport "$port" -j DROP
                    log_info "🚫 已阻止UDP端口: $port"
                fi
            fi
        done
    fi

    # 插入端口限制链
    iptables -C FORWARD -j SECURITY_PORT_RESTRICTIONS 2>/dev/null || iptables -I FORWARD -j SECURITY_PORT_RESTRICTIONS
}

# 应用地域限制规则 (新疆地区IP集)
apply_geo_restrictions() {
    local rules_file="$1"

    # 创建或清空地域限制链
    iptables -F SECURITY_GEO_RESTRICTIONS 2>/dev/null || iptables -N SECURITY_GEO_RESTRICTIONS

    # 检查是否有中国或新疆地区的限制
    local has_china_block=false
    local has_xinjiang_block=false

    if command -v jq >/dev/null 2>&1; then
        if jq -e '.geo_restrictions[] | select(.country=="CN" and .type=="block")' "$rules_file" >/dev/null 2>&1; then
            has_china_block=true
        fi
        if jq -e '.geo_restrictions[] | select(.country=="XJ" and .type=="block")' "$rules_file" >/dev/null 2>&1; then
            has_xinjiang_block=true
        fi
    else
        if grep -q '"country":"CN".*"type":"block"' "$rules_file" 2>/dev/null; then
            has_china_block=true
        fi
        if grep -q '"country":"XJ".*"type":"block"' "$rules_file" 2>/dev/null; then
            has_xinjiang_block=true
        fi
    fi

    # 应用新疆地区IP段限制
    if [ "$has_china_block" = true ] || [ "$has_xinjiang_block" = true ]; then
        log_info "🌍 应用新疆地区IP限制..."

        # 下载新疆IP段文件（如果不存在）
        local xinjiang_ip_file="/tmp/xinjiang-ip-ranges.txt"
        if [ ! -f "$xinjiang_ip_file" ]; then
            log_info "📥 下载新疆IP段数据..."
            curl -s -o "$xinjiang_ip_file" "$API_BASE_URL/static/xinjiang-ip-ranges.txt" || {
                log_warning "⚠️ 无法下载新疆IP段文件，使用内置IP段"
                # 创建基本的新疆IP段文件
                cat > "$xinjiang_ip_file" << 'EOF'
# 新疆维吾尔自治区主要IP段
61.128.0.0/10
61.136.0.0/13
118.178.0.0/16
121.196.0.0/16
124.117.0.0/16
180.148.0.0/16
202.201.0.0/16
60.12.0.0/16
60.13.0.0/16
118.179.0.0/16
119.42.0.0/16
124.88.0.0/16
125.75.0.0/16
111.40.0.0/16
111.41.0.0/16
117.177.0.0/16
117.178.0.0/16
183.156.0.0/16
183.157.0.0/16
EOF
            }
        fi

        # 读取IP段文件并应用规则
        local blocked_count=0
        while IFS= read -r ip_range; do
            # 跳过注释行和空行
            if [[ "$ip_range" =~ ^[[:space:]]*# ]] || [[ -z "$ip_range" ]]; then
                continue
            fi

            # 清理行末空格
            ip_range=$(echo "$ip_range" | tr -d '[:space:]')

            if [ -n "$ip_range" ]; then
                iptables -A SECURITY_GEO_RESTRICTIONS -s "$ip_range" -j DROP
                iptables -A SECURITY_GEO_RESTRICTIONS -d "$ip_range" -j DROP
                blocked_count=$((blocked_count + 1))

                # 每10个IP段记录一次日志，避免日志过多
                if [ $((blocked_count % 10)) -eq 0 ]; then
                    log_info "🚫 已阻止 $blocked_count 个新疆IP段..."
                fi
            fi
        done < "$xinjiang_ip_file"

        log_info "✅ 新疆地区IP限制应用完成，共阻止 $blocked_count 个IP段"
    fi

    # 插入地域限制链
    iptables -C INPUT -j SECURITY_GEO_RESTRICTIONS 2>/dev/null || iptables -I INPUT -j SECURITY_GEO_RESTRICTIONS
    iptables -C OUTPUT -j SECURITY_GEO_RESTRICTIONS 2>/dev/null || iptables -I OUTPUT -j SECURITY_GEO_RESTRICTIONS
}

# 应用安全规则
apply_security_rules() {
    local rules_file="/tmp/security_rules.json"

    if [ -f "$rules_file" ]; then
        log_info "🛡️ 开始应用安全规则..."

        # 应用IP黑名单
        apply_ip_blacklist "$rules_file"

        # 🆕 应用域名黑名单
        apply_domain_blacklist "$rules_file"

        # 应用端口限制
        apply_port_restrictions "$rules_file"

        # 应用地域限制（包括新疆地区）
        apply_geo_restrictions "$rules_file"

        log_info "✅ 安全规则应用完成"
    else
        log_info "📋 未找到安全规则文件，跳过规则应用"
    fi
}

# 🔧 新增：服务器流量汇总上报（5分钟一次，精确字节数）
report_server_traffic_bytes() {
    local bytes_used="$1"
    local connection_count="$2"

    local payload="{
        \"server_id\":\"$SERVER_ID\",
        \"bytes_used\":$bytes_used,
        \"event_type\":\"server_summary\",
        \"timestamp\":$(date +%s),
        \"connection_count\":$connection_count
    }"

    local response=$(curl -s -w "HTTPSTATUS:%{http_code}" -X POST "$API_BASE_URL/api/traffic/report" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_TOKEN" \
        -d "$payload" \
        --connect-timeout 5 \
        --max-time 10)

    local http_code=$(echo "$response" | tr -d '\n' | sed -e 's/.*HTTPSTATUS://')
    local body=$(echo "$response" | sed -e 's/HTTPSTATUS\:.*//g')

    if [ "$http_code" = "200" ]; then
        log_info "📊 服务器流量上报成功: $(format_bytes $bytes_used)"
    else
        log_error "📊 服务器流量上报失败: HTTP $http_code, $body"
    fi
}

# 🔧 保留旧函数以兼容性（已弃用）
report_server_traffic() {
    local traffic_mb="$1"
    local connection_count="$2"

    # 转换为字节并调用新函数
    local bytes_used=$((traffic_mb * 1024 * 1024))
    report_server_traffic_bytes "$bytes_used" "$connection_count"
}

# 发送心跳（增强版：支持安全规则）
send_heartbeat() {
    local current_version=$(get_current_security_version)
    local payload="{
        \"server_id\":\"$SERVER_ID\",
        \"timestamp\":$(date +%s),
        \"status\":\"online\",
        \"security_rules_version\":\"$current_version\"
    }"

    # 🔧 发送心跳并获取响应
    local response=$(curl -s -w "HTTPSTATUS:%{http_code}" -X POST "$API_BASE_URL/api/traffic/heartbeat" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_TOKEN" \
        -d "$payload" \
        --connect-timeout 5 \
        --max-time 10)

    # 解析响应
    local http_code=$(echo "$response" | tr -d '\n' | sed -e 's/.*HTTPSTATUS://')
    local body=$(echo "$response" | sed -e 's/HTTPSTATUS\:.*//g')

    if [ "$http_code" = "200" ]; then
        log_info "💓 心跳发送成功"

        # 🛡️ 检查是否有安全规则更新
        if echo "$body" | grep -q '"rules_update"'; then
            log_info "🛡️ 检测到安全规则更新，开始下载..."

            # 提取规则更新部分并保存
            echo "$body" | sed 's/.*"rules_update":\({.*}\).*/\1/' > "/tmp/security_rules.json"

            # 提取新版本号
            local new_version=$(echo "$body" | sed 's/.*"version":"\([^"]*\)".*/\1/')
            if [ -n "$new_version" ] && [ "$new_version" != "$current_version" ]; then
                log_info "🔄 安全规则版本更新: $current_version → $new_version"
                save_security_version "$new_version"

                # 应用新的安全规则
                apply_security_rules
            fi
        fi
    else
        log_error "💔 心跳发送失败: HTTP $http_code, $body"
    fi
}

# 🆕 真实流量监控主循环 - 完全移除流量分配算法
main_monitor_loop() {
    local interface=$(get_main_interface)
    local last_rx=0
    local last_tx=0
    local heartbeat_counter=0
    local accumulated_traffic=0  # 节点系统流量统计
    local connection_count=0

    log_info "🚀 开始真实流量监控..."
    log_info "📡 监控网络接口: $interface"
    log_info "🔄 上报间隔: ${REPORT_INTERVAL}秒"
    log_info "🎯 监控模式: 真实用户流量监控（无流量分配）"

    # 🛡️ 初始化安全规则
    log_info "🛡️ 初始化安全规则系统..."
    apply_security_rules

    # 🆕 真实流量监控：用户监控状态跟踪
    declare -A user_monitoring_active    # 用户监控是否激活
    declare -A user_last_traffic        # 用户上次流量数据
    declare -A user_last_seen           # 用户最后活跃时间

    # 获取初始流量数据
    read last_rx last_tx <<< $(get_interface_stats "$interface")

    while true; do
        sleep $REPORT_INTERVAL

        # 🔧 修改：只统计VPN端口相关的流量，而不是整个网络接口
        # 获取VPN端口的流量统计（基于iptables计数器）
        local vpn_traffic_diff=0

        # 统计所有VPN端口的流量
        for port in 443 80 8080 1080 10808; do
            # 获取该端口的入站和出站字节数
            local port_in_bytes=$(iptables -L INPUT -v -n -x 2>/dev/null | grep "dpt:$port" | awk '{sum+=$2} END {print sum+0}')
            local port_out_bytes=$(iptables -L OUTPUT -v -n -x 2>/dev/null | grep "spt:$port" | awk '{sum+=$2} END {print sum+0}')
            local port_total=$((port_in_bytes + port_out_bytes))

            # 计算与上次的差值
            local last_port_key="last_port_${port}_traffic"
            local last_port_traffic=${!last_port_key:-0}
            local port_diff=$((port_total - last_port_traffic))

            if [ $port_diff -gt 0 ]; then
                vpn_traffic_diff=$((vpn_traffic_diff + port_diff))
            fi

            # 更新记录
            declare -g "$last_port_key=$port_total"
        done

        # 获取连接数
        local connections=$(get_active_connections)

        # 🔧 只累积VPN相关流量，而不是整个系统流量
        if [ $vpn_traffic_diff -gt 0 ]; then
            log_info "📊 检测到VPN流量: $(format_bytes $vpn_traffic_diff), 连接数: $connections"
            accumulated_traffic=$((accumulated_traffic + vpn_traffic_diff))
        fi

        # 🆕 真实流量监控：获取当前活跃用户和IP映射
        local active_users_with_ips=""
        # 🔧 关键修复：每次循环都清空用户映射，避免使用上次循环的数据
        unset user_ip_mapping
        declare -A user_ip_mapping  # 用户IP映射表

        # 🔧 修复：无论连接数如何，都要调用API检查用户状态
        # 这样可以及时发现用户离线，停止更新活跃时间
        log_info "🔍 检查活跃用户状态 (当前连接数: $connections)"
        active_users_with_ips=$(get_all_active_users_with_ips)
        local api_success=$?

        # 🔧 修复：只有API成功返回用户时才处理
        if [ $api_success -eq 0 ] && [ -n "$active_users_with_ips" ]; then
            log_info "✅ API返回活跃用户，开始解析用户IP映射"
            # 解析用户IP映射
            while IFS= read -r user_ip_pair; do
                if [ -n "$user_ip_pair" ] && [[ "$user_ip_pair" == *":"* ]]; then
                    local username=$(echo "$user_ip_pair" | cut -d':' -f1)
                    local user_ip=$(echo "$user_ip_pair" | cut -d':' -f2)
                    user_ip_mapping["$username"]="$user_ip"
                    log_info "🔗 解析用户映射: $username → $user_ip"
                fi
            done <<< "$active_users_with_ips"
        else
            log_info "ℹ️ API未返回活跃用户 (返回码: $api_success)"
        fi

        # 🆕 真实流量监控：处理活跃用户
        if [ ${#user_ip_mapping[@]} -gt 0 ]; then
            log_info "🔍 API返回了 ${#user_ip_mapping[@]} 个活跃用户，开始处理流量监控"
            # 获取用户列表，再次过滤确保安全
            local user_list=()
            for username in "${!user_ip_mapping[@]}"; do
                # 🔧 最后一道防线：确保用户名绝对安全
                if [ -n "$username" ] && [[ "$username" =~ ^[a-zA-Z0-9_-]+$ ]] && [[ ${#username} -le 15 ]] && [[ "$username" != *"["* ]] && [[ "$username" != *"2025-"* ]] && [[ "$username" != *"INFO:"* ]]; then
                    user_list+=("$username")
                else
                    log_warning "⚠️ 最终过滤：移除异常用户名 '$username'"
                    unset user_ip_mapping["$username"]
                fi
            done

            local user_count=${#user_list[@]}
            log_info "🔍 发现 $user_count 个活跃用户，开始真实流量监控"

            # 为每个活跃用户启动监控
            for username in "${user_list[@]}"; do
                # 检查是否已启动监控
                if [ -z "${user_monitoring_active[$username]}" ]; then
                    create_user_traffic_monitoring "$username"
                    if [ $? -eq 0 ]; then
                        user_monitoring_active["$username"]=1
                        user_last_traffic["$username"]=0
                        log_info "✅ 为用户 $username 启动真实流量监控"
                    fi
                fi

                # 🔧 修复：只有API返回的活跃用户才更新最后活跃时间
                # 这样当用户离线时，API不再返回该用户，活跃时间停止更新，5分钟后自动清理
                user_last_seen["$username"]=$(date +%s)
            done

            # 🔧 真实流量监控：获取每个用户的实际流量使用量（基于iptables统计）
            # 🔧 修复：只处理API返回的活跃用户，避免对离线用户继续统计
            for username in "${user_list[@]}"; do
                if [ "${user_monitoring_active[$username]}" = "1" ]; then
                    # 🔧 获取用户的真实iptables流量统计
                    local current_traffic=$(get_user_real_traffic_usage "$username")
                    local last_traffic=${user_last_traffic[$username]:-0}

                    # 计算流量增量
                    local traffic_diff=$((current_traffic - last_traffic))

                    if [ $traffic_diff -gt 0 ]; then
                        local user_ip=${user_ip_mapping[$username]:-"unknown"}
                        log_info "📊 用户 $username (IP: $user_ip) 真实流量: 新增 $(format_bytes $traffic_diff), 总计 $(format_bytes $current_traffic)"

                        # 🔧 立即上报用户的真实流量增量（包含IP信息）
                        log_info "🔍 DEBUG: 准备上报用户 $username 流量，来源：API返回的活跃用户列表"
                        report_traffic "$username" "$traffic_diff" "$user_count" "$user_ip"

                        # 更新用户流量记录
                        user_last_traffic["$username"]=$current_traffic
                    else
                        # 显示当前状态（即使没有变化）
                        if [ $current_traffic -gt 0 ]; then
                            log_info "📊 用户 $username 当前总流量: $(format_bytes $current_traffic) (本周期无新增)"
                        fi
                    fi
                fi
            done
        else
            # 🔧 新逻辑：API返回空用户时，立即处理所有离线用户
            if [ ${#user_monitoring_active[@]} -gt 0 ]; then
                log_info "⚠️ API返回空用户列表，检测到用户离线，立即处理离线用户"
                log_info "👥 发现 ${#user_monitoring_active[@]} 个用户需要离线处理"

                # 🔧 立即处理所有离线用户：上报剩余流量并清理规则
                for username in "${!user_monitoring_active[@]}"; do
                    # 过滤异常用户名
                    if [ -z "$username" ] || [[ "$username" == *"["* ]] || [[ "$username" == *"INFO:"* ]] || [[ "$username" == *"WARNING:"* ]] || [[ "$username" == *"ERROR:"* ]] || [[ "$username" == *"2025-"* ]]; then
                        log_warning "⚠️ 发现异常用户名 '$username'，直接清理"
                        unset user_monitoring_active["$username"]
                        unset user_last_traffic["$username"]
                        unset user_last_seen["$username"]
                        continue
                    fi

                    log_info "👋 处理离线用户: $username"

                    # 1. 获取用户最后的流量数据
                    local current_traffic=$(get_user_real_traffic_usage "$username")
                    local last_traffic=${user_last_traffic[$username]:-0}
                    local traffic_diff=$((current_traffic - last_traffic))

                    # 2. 如果有剩余流量，立即上报
                    if [ $traffic_diff -gt 0 ]; then
                        local user_ip="offline"  # 用户已离线，IP不可用
                        log_info "📊 用户 $username 离线前剩余流量: $(format_bytes $traffic_diff), 总计: $(format_bytes $current_traffic)"
                        log_info "🔍 立即上报用户 $username 的离线流量"
                        report_traffic "$username" "$traffic_diff" "0" "$user_ip"
                    fi

                    # 3. 立即清理iptables规则和内存数据
                    log_info "🧹 立即清理用户 $username 的iptables规则"
                    cleanup_user_traffic_monitoring "$username"

                    # 4. 清理内存数据
                    unset user_monitoring_active["$username"]
                    unset user_last_traffic["$username"]
                    unset user_last_seen["$username"]

                    log_success "✅ 用户 $username 离线处理完成：流量已上报，规则已清理"
                done

                log_success "🎉 所有离线用户处理完成"
            fi
        fi

        # 🔧 新逻辑：不再需要延迟清理机制，因为已经实现了立即清理
        # 只保留异常用户名的清理，作为安全保障
        for username in "${!user_monitoring_active[@]}"; do
            # 清理可能残留的异常用户名
            if [ -z "$username" ] || [[ "$username" == *"["* ]] || [[ "$username" == *"INFO:"* ]] || [[ "$username" == *"WARNING:"* ]] || [[ "$username" == *"ERROR:"* ]] || [[ "$username" == *"2025-"* ]]; then
                log_warning "⚠️ 清理残留的异常用户名 '$username'"
                unset user_monitoring_active["$username"]
                unset user_last_traffic["$username"]
                unset user_last_seen["$username"]
            fi
        done

        # 🔧 更新连接数计数器
        connection_count=$connections

        # 🔧 注释掉网络接口流量更新，因为我们现在使用VPN端口流量统计
        # last_rx=$current_rx
        # last_tx=$current_tx

        # 🔧 每1分钟上报用户流量，每2分钟发送心跳和节点流量
        heartbeat_counter=$((heartbeat_counter + 1))

        # 🔧 真实流量监控：每1分钟上报用户流量数据
        if [ $((heartbeat_counter % 1)) -eq 0 ]; then
            # 统计当前监控的用户数量
            local active_monitoring_count=0
            for username in "${!user_monitoring_active[@]}"; do
                if [ "${user_monitoring_active[$username]}" = "1" ]; then
                    active_monitoring_count=$((active_monitoring_count + 1))
                fi
            done

            if [ $active_monitoring_count -gt 0 ]; then
                log_info "👥 当前监控 $active_monitoring_count 个用户的流量"
            else
                log_info "📊 当前无用户流量监控"
            fi
        fi

        # 每2分钟发送心跳和节点汇总流量
        if [ $((heartbeat_counter % 2)) -eq 0 ]; then
            send_heartbeat
            log_info "💓 发送心跳信号"

            # 🔧 节点汇总流量上报（2分钟一次）- 这是系统级别的独立流量统计
            if [ "$accumulated_traffic" -gt 0 ]; then
                # 🔧 节点流量统计不关心用户数，使用固定值或连接数
                report_server_traffic_bytes "$accumulated_traffic" "$connections"
                log_info "📊 已上报2分钟节点系统流量: $(format_bytes $accumulated_traffic) (独立于用户流量统计)"
                accumulated_traffic=0  # 🔧 上报后立即归零，重新开始统计
            else
                log_info "📊 2分钟内无系统流量，跳过节点汇总上报"
            fi
        fi
    done
}

# 检查依赖
check_dependencies() {
    if ! command -v curl >/dev/null 2>&1; then
        log_error "❌ curl 未安装，请先安装: apt install -y curl"
        exit 1
    fi
    
    if ! command -v netstat >/dev/null 2>&1; then
        log_warning "⚠️ netstat 未安装，连接统计功能受限"
    fi
    
    log_success "✅ 依赖检查通过"
}

# 信号处理
cleanup() {
    log_info "🛑 收到停止信号，正在清理..."
    exit 0
}

trap cleanup SIGTERM SIGINT

# 主函数
main() {
    log_info "🎯 启动纯Bash流量监控脚本"
    log_info "🖥️  服务器ID: $SERVER_ID"
    log_info "🌐 API地址: $API_BASE_URL"
    
    check_dependencies
    main_monitor_loop
}

# 如果直接运行此脚本
if [ "${BASH_SOURCE[0]}" == "${0}" ]; then
    main "$@"
fi
