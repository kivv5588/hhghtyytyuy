#!/bin/bash

# =============================================================================
# 一键安装脚本 - 节点服务器流量监控
# 适用于：Ubuntu 24.04 LTS
# 功能：自动安装和配置流量监控服务
# =============================================================================

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 配置参数（可以通过环境变量覆盖）
API_BASE_URL="${API_BASE_URL:-http://173.230.128.51:8080}"
SERVER_ID="${SERVER_ID:-node-$(hostname -I | awk '{print $1}' | tr '.' '-')}"
API_TOKEN="${API_TOKEN:-fgfrerrhtrytrytrfdgdgdfggrtre}"
REPORT_INTERVAL="${REPORT_INTERVAL:-60}"

# 显示配置信息
show_config() {
    log_info "📋 安装配置:"
    echo "  🌐 API地址: $API_BASE_URL"
    echo "  🖥️  服务器ID: $SERVER_ID"
    echo "  🔑 API令牌: ${API_TOKEN:0:10}..."
    echo "  ⏱️  上报间隔: ${REPORT_INTERVAL}秒"
    echo ""
}

# 检查系统环境
check_system() {
    log_info "🔍 检查系统环境..."
    
    # 检查是否为root用户
    if [ "$EUID" -ne 0 ]; then
        log_error "请以root权限运行此脚本"
        exit 1
    fi
    
    # 检查Ubuntu版本
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        if [[ "$ID" != "ubuntu" ]]; then
            log_warning "此脚本专为Ubuntu设计，当前系统: $ID"
        fi
        log_info "系统版本: $PRETTY_NAME"
    fi
    
    log_success "✅ 系统环境检查通过"
}

# 安装依赖
install_dependencies() {
    log_info "📦 安装必要依赖..."
    
    # 更新包列表
    apt update -qq
    
    # 安装curl（通常已安装）
    if ! command -v curl >/dev/null 2>&1; then
        apt install -y curl
        log_success "✅ curl 安装完成"
    else
        log_info "✅ curl 已安装"
    fi
    
    # 安装net-tools（用于netstat）
    if ! command -v netstat >/dev/null 2>&1; then
        apt install -y net-tools
        log_success "✅ net-tools 安装完成"
    else
        log_info "✅ net-tools 已安装"
    fi
    
    log_success "✅ 依赖安装完成"
}

# 停止现有服务
stop_existing_services() {
    log_info "🛑 停止现有监控服务..."
    
    # 停止可能存在的服务
    systemctl stop simple-traffic-monitor 2>/dev/null || true
    systemctl stop traffic-monitor-fixed 2>/dev/null || true
    
    # 杀死可能运行的脚本
    pkill -f "simple-traffic-monitor.sh" 2>/dev/null || true
    pkill -f "server_traffic_monitor.py" 2>/dev/null || true
    
    log_success "✅ 现有服务已停止"
}

# 创建监控脚本
create_monitor_script() {
    log_info "📝 创建监控脚本..."
    
    # 创建脚本目录
    mkdir -p /opt/traffic-monitor
    
    # 直接复制完整的监控脚本
    if [ -f "simple-traffic-monitor.sh" ]; then
        cp simple-traffic-monitor.sh /opt/traffic-monitor/simple-traffic-monitor.sh

        # 替换配置参数
        sed -i "s|API_BASE_URL=\".*\"|API_BASE_URL=\"$API_BASE_URL\"|g" /opt/traffic-monitor/simple-traffic-monitor.sh
        sed -i "s|SERVER_ID=\".*\"|SERVER_ID=\"$SERVER_ID\"|g" /opt/traffic-monitor/simple-traffic-monitor.sh
        sed -i "s|API_TOKEN=\".*\"|API_TOKEN=\"$API_TOKEN\"|g" /opt/traffic-monitor/simple-traffic-monitor.sh
        sed -i "s|REPORT_INTERVAL=.*|REPORT_INTERVAL=$REPORT_INTERVAL|g" /opt/traffic-monitor/simple-traffic-monitor.sh
    else
        log_error "❌ 找不到监控脚本文件 simple-traffic-monitor.sh"
        exit 1
    fi
    
    # 设置执行权限
    chmod +x /opt/traffic-monitor/simple-traffic-monitor.sh
    
    log_success "✅ 监控脚本创建完成"
}

# 创建系统服务
create_systemd_service() {
    log_info "⚙️ 创建系统服务..."
    
    cat > /etc/systemd/system/simple-traffic-monitor.service << EOF
[Unit]
Description=Simple Traffic Monitor Service
After=network.target
Wants=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/traffic-monitor
ExecStart=/opt/traffic-monitor/simple-traffic-monitor.sh
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

# 环境变量
Environment=PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

[Install]
WantedBy=multi-user.target
EOF

    # 重新加载systemd
    systemctl daemon-reload
    systemctl enable simple-traffic-monitor.service
    
    log_success "✅ 系统服务创建完成"
}

# 测试API连接
test_api_connection() {
    log_info "🔗 测试API连接..."
    
    local response=$(curl -s -X POST "$API_BASE_URL/api/traffic/heartbeat" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_TOKEN" \
        -d "{\"server_id\":\"$SERVER_ID\",\"timestamp\":$(date +%s),\"status\":\"online\"}" \
        --connect-timeout 10 \
        --max-time 15 2>/dev/null)
    
    if [ $? -eq 0 ] && echo "$response" | grep -q "success"; then
        log_success "✅ API连接测试成功"
        return 0
    else
        log_error "❌ API连接测试失败: $response"
        return 1
    fi
}

# 启动服务
start_service() {
    log_info "🚀 启动监控服务..."
    
    systemctl start simple-traffic-monitor.service
    sleep 3
    
    if systemctl is-active --quiet simple-traffic-monitor.service; then
        log_success "✅ 监控服务启动成功"
    else
        log_error "❌ 监控服务启动失败"
        systemctl status simple-traffic-monitor.service
        return 1
    fi
}

# 显示状态和管理命令
show_management_info() {
    log_success "🎉 安装完成！"
    echo ""
    echo "📊 服务状态:"
    systemctl status simple-traffic-monitor.service --no-pager -l
    echo ""
    echo "🛠️ 管理命令:"
    echo "  查看状态: systemctl status simple-traffic-monitor"
    echo "  查看日志: journalctl -u simple-traffic-monitor -f"
    echo "  重启服务: systemctl restart simple-traffic-monitor"
    echo "  停止服务: systemctl stop simple-traffic-monitor"
    echo "  查看配置: cat /opt/traffic-monitor/simple-traffic-monitor.sh | head -20"
    echo ""
    echo "📁 文件位置:"
    echo "  监控脚本: /opt/traffic-monitor/simple-traffic-monitor.sh"
    echo "  系统服务: /etc/systemd/system/simple-traffic-monitor.service"
    echo "  日志文件: /var/log/traffic-monitor.log"
}

# 主安装流程
main() {
    echo "🚀 节点服务器流量监控 - 一键安装脚本"
    echo "适用于: Ubuntu 24.04 LTS"
    echo "========================================"
    echo ""
    
    show_config

    # 🔧 移除多余的确认提示，直接开始安装
    log_info "开始自动安装流量监测功能..."
    
    check_system
    install_dependencies
    stop_existing_services
    create_monitor_script
    create_systemd_service
    
    if test_api_connection; then
        start_service
        show_management_info
    else
        log_warning "⚠️ API连接测试失败，但服务已安装"
        log_warning "请检查网络连接和API配置后手动启动服务"
        echo "手动启动: systemctl start simple-traffic-monitor"
    fi
}

# 执行主函数
main "$@"
